import json, re, subprocess, collections, unicodedata
days=json.load(open("days_raw.json"))
def key(tok):
    tok=unicodedata.normalize("NFKC",tok)
    chs=[c for c in tok if c.isalnum() or c in "ـ"]
    return "".join(sorted(chs))
def toks(s):
    s=re.sub(r"[\u200e\u200f\u202a-\u202e\u2066-\u2069]","",s)
    return [key(t) for t in re.split(r"\s+",s) if key(t)]
def letters_only(ks): return [k for k in ks if not any(ch.isdigit() for ch in k) or re.search(r"[^\W\d]",k)]
def mine_strings(d):
    out=[]
    for sec in d.get("sections",[]):
        out.append(("subject",sec["subject"]))
        for p in sec["periods"]:
            for it in p["items"]:
                if it["group"]: out.append(("group",it["group"]))
                out.append(("title",it["title"]))
    for il in d.get("interludes",[]):
        if il["type"]=="free_time": out.append(("free",il["label"]))
    out.append(("header",d["headerTitle"]))
    return out
fails=[]; checked=0
for d in days:
    pg=d["page"]
    raw=subprocess.run(["pdftotext","-f",str(pg),"-l",str(pg),"-raw","plan.pdf","-"],capture_output=True,text=True).stdout
    PT=toks(raw)
    PTset=collections.Counter(PT)
    for kind,s in mine_strings(d):
        K=toks(s)
        if not K: continue
        checked+=1
        # (1) each token must exist on the page in the independent text (multiset check done globally below)
        miss=[k for k in K if k not in PTset]
        # (2) order: contiguous subsequence?
        n=len(K); ok=any(PT[i:i+n]==K or PT[i:i+n]==K[::-1] for i in range(len(PT)-n+1))
        if miss or not ok: fails.append((d["day"],pg,kind,s,"missing" if miss else "order"))
    # (3) page level multiset of characters (letters/digits) must be equal
print("strings checked:",checked,"failures:",len(fails))
for f in fails[:60]: print(f)
