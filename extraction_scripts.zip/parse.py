import re, json, sys, pdfplumber
from lib import lines_of, split_cells, cell_text

RED=(0.5608,0.1098,0.0824); BLUE=(0.1059,0.1922,0.2863)
def close(a,b,t=0.03):
    return a is not None and len(a)==3 and all(abs(x-y)<t for x,y in zip(a,b))

TIME=re.compile(r"^(\d{1,2}):(\d{2}) – (\d{1,2}):(\d{2})$")
def fmt(m): return f"{m//60:02d}:{m%60:02d}"
def abs24(h,mi,ap): return (h%12)*60+mi+(720 if ap=="م" else 0)

class Cell:
    def __init__(s,chars):
        s.text=cell_text(chars)
        m=chars[len(chars)//2]
        s.x0=min(c["x0"] for c in chars); s.x1=max(c["x1"] for c in chars)
        s.top=sum(c["top"] for c in chars)/len(chars)
        s.color=m.get("non_stroking_color"); s.size=m["size"]; s.font=m["fontname"]
    @property
    def white(s): return close(s.color,(1,1,1))
    @property
    def cx(s): return (s.x0+s.x1)/2

def page_cells(page, gap=9.0):
    out=[]
    for r in lines_of(page):
        for c in split_cells(r["chars"],gap):
            out.append(Cell(c))
    return out

class Mono:
    """convert H:MM tokens (no am/pm) to absolute minutes, monotone non-decreasing."""
    def __init__(s,prev): s.prev=prev
    def conv(s,h,mi):
        base=(h%12)*60+mi
        for add in (0,720,1440):
            if base+add>=s.prev-0: 
                s.prev=base+add; return base+add
        raise ValueError("time goes backwards")

def parse_page(page, pno):
    cells=page_cells(page)
    d={"page":pno}
    # header
    hdr=[c for c in cells if c.top<82]
    wk=[c for c in hdr if re.match(r"^الأسبوع \d+$",c.text)]
    d["week"]=int(re.search(r"\d+",wk[0].text).group()) if wk else None
    dayrow=[c for c in page_cells(page,gap=4.0) if c.top<85 and c.x1>370 and not c.text.startswith('الأسبوع')]
    dayrow.sort(key=lambda c:-c.x1)
    dtext=" ".join(c.text for c in dayrow)
    m=re.match(r"^اليوم (\d+)\s*(.*)$",dtext)
    d["day"]=int(m.group(1)); d["headerTitle"]=m.group(2).strip()
    st=[c for c in hdr if c.text.startswith("دراسة")]
    if st:
        m=re.match(r"^دراسة (\d+) س(?: (\d+) د)? · (\d{1,2}):(\d{2}) (ص|م) – (\d{1,2}):(\d{2}) (ص|م)$",st[0].text)
        if not m: raise ValueError("bad study header: "+st[0].text)
        d["statedStudyMinutes"]=int(m.group(1))*60+int(m.group(2) or 0)
        d["statedStart"]=fmt(abs24(int(m.group(3)),int(m.group(4)),m.group(5)))
        d["statedEnd"]=fmt(abs24(int(m.group(6)),int(m.group(7)),m.group(8)))
    d["type"]="practical" if "يوم عملي" in d["headerTitle"] else ("rest" if "عطلة" in d["headerTitle"] else "normal")
    if d["type"]=="rest":
        d["restNote"]=" ".join(c.text for c in cells if c.top>76 and "عطلة" not in c.text and not c.text.startswith("اليوم"))
        return d
    body=[c for c in cells if c.top>=95]
    # section headers
    sections=[]; events=[]
    subj_cells=[c for c in body if abs(c.size-11.2)<0.6 and c.x0>450]
    for sc in subj_cells:
        rng=[c for c in body if abs(c.top-sc.top)<4 and c is not sc and abs(c.size-8.2)<0.5 and c.x0<450]
        events.append(("section",sc.top,{"subject":sc.text,"rangeText":rng[0].text if rng else None}))
    SKIP={"✓","الدراسة","الحضور","الفيديو","الفترة"}
    plabels=[]   # period cells
    attend=[]; study=[]; bars=[]; titles=[]
    for c in body:
        t=c.text
        if c in subj_cells or (abs(c.size-8.2)<0.5 and c.text.find("الفترة")>=0 and "·" in c.text): continue
        if c.white:
            if t in SKIP: continue
            if t.startswith("وقت حر"):
                m=re.match(r"^(وقت حر .+?) · (\d{1,2}):(\d{2}) – (\d{1,2}):(\d{2})$",t)
                events.append(("free",c.top,{"raw":t,"label":m.group(1),"m":m.groups()[1:]})); continue
            if "ساعة حل أسئلة دورات" in t:
                bars.append(c); continue
            if TIME.match(t) and c.cx<150: continue   # bar interval, consumed with its bar
            raise ValueError(f"page {pno}: unhandled white cell {t!r} x={c.x0:.0f}-{c.x1:.0f} top={c.top:.1f}")
        if t.startswith("استراحة ربع ساعة"):
            m=re.match(r"^استراحة ربع ساعة · (\d{1,2}):(\d{2}) – (\d{1,2}):(\d{2})$",t)
            events.append(("break",c.top,{"raw":t,"m":m.groups()})); continue
        if t.startswith("وقت حر"):
            m=re.match(r"^(وقت حر .+?) · (\d{1,2}):(\d{2}) – (\d{1,2}):(\d{2})$",t)
            events.append(("free",c.top,{"raw":t,"label":m.group(1),"m":m.groups()[1:]})); continue
        if c.x0>=500:
            plabels.append(c); continue
        if TIME.match(t) and c.x1<195:
            (study if c.cx<125 else attend).append(c); continue
        if close(c.color,RED) and c.x1>370:
            events.append(("group",c.top,{"label":t})); continue
        if close(c.color,BLUE) and c.x1>430:
            titles.append(c); continue
        raise ValueError(f"page {pno}: unclassified cell {t!r} x={c.x0:.0f}-{c.x1:.0f} top={c.top:.1f}")
    # white interval cells for bars
    wtimes=[c for c in body if c.white and TIME.match(c.text) and c.cx<150]
    for b in bars:
        if "ساعة حل أسئلة دورات" not in b.text: continue
        w=[x for x in wtimes if abs(x.top-b.top)<4]
        if len(w)!=1: raise ValueError(f"page {pno}: bar without single interval: {b.text}")
        events.append(("bar",b.top,{"title":b.text,"m":TIME.match(w[0].text).groups()}))
    # video entries
    entries=[]
    for a in attend:
        s=[x for x in study if abs(x.top-a.top)<3]
        if len(s)!=1: raise ValueError(f"page {pno}: attendance {a.text} without single study")
        entries.append({"top":a.top,"a":TIME.match(a.text).groups(),"s":TIME.match(s[0].text).groups(),"titles":[]})
    if len(entries)*1!=len(study) : raise ValueError(f"page {pno}: unmatched study cells")
    for t in sorted(titles,key=lambda c:c.top):
        best=min(entries,key=lambda e:abs(e["top"]-t.top))
        if abs(best["top"]-t.top)>9: raise ValueError(f"page {pno}: title {t.text!r} far from entry")
        best["titles"].append(t.text)
    for e in entries:
        if not e["titles"]: raise ValueError(f"page {pno}: entry without title at {e['top']}")
        events.append(("video",e["top"],e))
    # period labels in order
    plabels.sort(key=lambda c:(c.top))
    periods=[]; cur=None
    for c in plabels:
        t=c.text
        m1=re.match(r"^الفترة (\d+)$",t); m2=re.match(r"^من (\d{1,2}):(\d{2}) (ص|م)$",t); m3=re.match(r"^لـ (\d{1,2}):(\d{2}) (ص|م)$",t)
        if m1: cur={"index":int(m1.group(1))}; periods.append(cur)
        elif m2: cur["from"]=abs24(int(m2.group(1)),int(m2.group(2)),m2.group(3))
        elif m3: cur["to"]=abs24(int(m3.group(1)),int(m3.group(2)),m3.group(3))
        else: raise ValueError(f"page {pno}: odd period cell {t!r}")
    events.sort(key=lambda e:e[1])
    # build blocks
    blocks=[]; cur=None; sec=None; group=None; secs=[]
    interludes=[]
    for kind,y,data in events:
        if kind=="section":
            sec={"subject":data["subject"],"rangeText":data["rangeText"],"periods":[]}; secs.append(sec); group=None; cur=None
        elif kind=="group": group=data["label"]
        elif kind in("break","free"):
            interludes.append({"type":kind,"raw":data,"after":len(blocks)}); cur=None
        else:
            if cur is None:
                cur={"sec":sec,"items":[]}; blocks.append(cur)
            cur["items"].append((kind,data,group))
    if len(blocks)!=len(periods): raise ValueError(f"page {pno}: {len(blocks)} blocks vs {len(periods)} period labels")
    mono=Mono(8*60)
    def tm(h,mi): return mono.conv(int(h),int(mi))
    out_secs=[]
    for blk,per in zip(blocks,periods):
        mono.prev=per["from"]
        items=[]
        for kind,data,grp in blk["items"]:
            if kind=="video":
                a0,a1=tm(data["a"][0],data["a"][1]),tm(data["a"][2],data["a"][3])
                s0,s1=tm(data["s"][0],data["s"][1]),tm(data["s"][2],data["s"][3])
                items.append({"type":"video","group":grp,"title":" ".join(data["titles"]),
                              "attendance":{"start":fmt(a0),"end":fmt(a1),"minutes":a1-a0},
                              "study":{"start":fmt(s0),"end":fmt(s1),"minutes":s1-s0}})
            else:
                s0,s1=tm(data["m"][0],data["m"][1]),tm(data["m"][2],data["m"][3])
                items.append({"type":"course_questions","group":grp,"title":data["title"],
                              "study":{"start":fmt(s0),"end":fmt(s1),"minutes":s1-s0}})
        first=items[0]; last=items[-1]
        fs=(first.get("attendance") or first["study"])["start"]; le=last["study"]["end"]
        per["itemsStart"]=fs; per["itemsEnd"]=le
        sec=blk["sec"]
        sec["periods"].append({"index":per["index"],"start":fmt(per["from"]),"end":fmt(per["to"]),"items":items,
                               "itemsStart":fs,"itemsEnd":le})
    d["sections"]=secs
    # interludes with times (monotone from previous period end)
    il=[]
    for it in interludes:
        prev_end=None
        k=it["after"]
        # previous period end
        flat=[p for s in secs for p in s["periods"]]
        pe=flat[k-1]["end"] if k>=1 else "08:00"
        mono.prev=int(pe[:2])*60+int(pe[3:])
        m=it["raw"]["m"]
        if it["type"]=="break":
            s0,s1=tm(m[0],m[1]),tm(m[2],m[3])
            il.append({"type":"break","afterPeriod":flat[k-1]["index"] if k>=1 else None,"start":fmt(s0),"end":fmt(s1),"minutes":s1-s0})
        else:
            s0,s1=tm(m[0],m[1]),tm(m[2],m[3])
            il.append({"type":"free_time","afterPeriod":flat[k-1]["index"] if k>=1 else None,"label":it["raw"]["label"],"start":fmt(s0),"end":fmt(s1),"minutes":s1-s0})
    d["interludes"]=il
    return d

if __name__=="__main__":
    pdf=pdfplumber.open("plan.pdf")
    days=[]; errs=[]
    for pno in range(7,75):
        try: days.append(parse_page(pdf.pages[pno-1],pno))
        except Exception as e:
            errs.append((pno,repr(e)))
    json.dump(days,open("days_raw.json","w"),ensure_ascii=False,indent=1)
    print("parsed",len(days),"errors",len(errs))
    for e in errs: print(e)
