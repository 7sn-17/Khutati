import json, datetime, collections, re
days=json.load(open("days_raw.json"))
intro=json.load(open("intro_raw.json"))
SK={"الكيمياء الطبية":"chem","الفيزياء الطبية":"phys","بيولوجيا الخلية":"bio","تاريخ الطب":"hist","انكليزي 1":"eng"}
FIX={"ٱ الحركية ولية التفاعل":"الحركية وآلية التفاعل"}   # verified visually (page 30): glyph is alef-madda inside "وآلية"
START=datetime.date(2026,11,19)
out_days=[]; fixes=[]
counts=collections.Counter()
last_day=collections.defaultdict(int)
for d in days:
    n=d["day"]; date=START+datetime.timedelta(days=n-1)
    od={"id":f"d{n:03d}","day":n,"date":date.isoformat(),"week":d["week"],"sourcePage":d["page"],"type":d["type"]}
    if d["type"]=="rest":
        od["title"]="يوم عطلة"; od["note"]=d["restNote"]; od["sections"]=[]; od["interludes"]=[]
        out_days.append(od); continue
    od["headerTitle"]=d["headerTitle"]
    od["statedStudyMinutes"]=d["statedStudyMinutes"]; od["start"]=d["statedStart"]; od["end"]=d["statedEnd"]
    a=st=c=0
    for sec in d["sections"]:
        for p in sec["periods"]:
            for it in p["items"]:
                if it["type"]=="video": a+=it["attendance"]["minutes"]; st+=it["study"]["minutes"]
                else: c+=it["study"]["minutes"]
    od["computed"]={"attendanceMinutes":a,"studyMinutes":st,"courseQuestionMinutes":c,"totalMinutes":a+st+c}
    secs=[]
    for si,sec in enumerate(d["sections"],1):
        key=SK[sec["subject"]]; last_day[key]=max(last_day[key],n)
        osec={"subject":sec["subject"],"subjectKey":key,"rangeText":sec["rangeText"],"periods":[]}
        seq=0
        for p in sec["periods"]:
            op={"index":p["index"],"start":p["start"],"end":p["end"],"items":[]}
            for it in p["items"]:
                seq+=1
                t=it["title"]
                if t in FIX: fixes.append((n,t,FIX[t])); t=FIX[t]
                oi={"id":f"d{n:03d}-{key}-{p['index']:02d}-{seq:02d}","type":it["type"],"group":it["group"],"title":t}
                if it["type"]=="video":
                    oi["attendance"]=it["attendance"]; oi["study"]=it["study"]; counts["video"]+=1
                else:
                    oi["study"]=it["study"]; counts["course_questions"]+=1
                op["items"].append(oi)
            osec["periods"].append(op)
        secs.append(osec)
    od["sections"]=secs
    od["interludes"]=d["interludes"]
    out_days.append(od)
# group names: also fix group strings if needed
meta={
 "name":"خطة إنهاء منهاج الفصل الأول — بروفيسور ميدكس",
 "source":"خطة-إنهاء-المنهاج-25-1 (74 صفحة)",
 "startDate":START.isoformat(),
 "startDateNote":"السنة 2026 افتراض من تاريخ المشروع؛ الـ PDF يذكر اليوم والشهر فقط (19 تشرين الثاني – 25 كانون الثاني)",
 "endDate":(START+datetime.timedelta(days=67)).isoformat(),
 "totalDays":68,"studyDays":64,"restDays":[15,30,45,60],
 "practicalDays":[d["day"] for d in days if d["type"]=="practical"],
 "statedTotals":{"attendance":"212 س 15 د","study":"207 س 54 د","courses":"60 س","all":"480 س 9 د"},
 "subjects":[
  {"key":"bio","name":"بيولوجيا الخلية","instructor":"د. توفيق القطان","attendance":"70 س 6 د","study":"69 س 19 د","courses":"11 س","total":"150 س 25 د"},
  {"key":"chem","name":"الكيمياء الطبية","instructor":"د. توفيق القطان","attendance":"63 س 16 د","study":"61 س 18 د","courses":"19 س","total":"143 س 34 د"},
  {"key":"phys","name":"الفيزياء الطبية","instructor":"أ. عمرو الحبش","attendance":"41 س 26 د","study":"40 س 52 د","courses":"16 س","total":"98 س 18 د"},
  {"key":"hist","name":"تاريخ الطب","instructor":"د. أسامة بركات","attendance":"17 س","study":"17 س","courses":"7 س","total":"41 س"},
  {"key":"eng","name":"انكليزي 1","instructor":"د. معاذ خطاب","attendance":"20 س 27 د","study":"19 س 25 د","courses":"7 س","total":"46 س 52 د"}],
 "lastDayPerSubject":dict(last_day),
 "introPages":{str(k):v for k,v in intro.items()},
}
data={"meta":meta,"days":out_days}
json.dump(data,open("/mnt/user-data/outputs/khutati_plan_data.json","w"),ensure_ascii=False,indent=1)
print("fixes:",fixes); print("counts:",dict(counts)); print("last day per subject:",dict(last_day))
print("date of day 68:",meta["endDate"])
print("rest dates:",[ (START+datetime.timedelta(days=n-1)).isoformat() for n in meta["restDays"]])
