import json, re, subprocess, collections, unicodedata
exec(open("crosscheck3.py").read().split("fails=[]")[0])
unexpl=[]
for d in days:
    pg=d["page"]
    raw=subprocess.run(["pdftotext","-f",str(pg),"-l",str(pg),"-raw","plan.pdf","-"],capture_output=True,text=True).stdout
    PT=toks(raw)
    for kind,s in mine_strings(d):
        K=toks(s)
        if not K: continue
        n=len(K)
        if any(PT[i:i+n]==K or PT[i:i+n]==K[::-1] for i in range(len(PT)-n+1)): continue
        # same multiset of tokens in some contiguous window of PT (order inside mixed-direction runs may differ)?
        sK=sorted(K)
        if any(sorted(PT[i:i+n])==sK for i in range(len(PT)-n+1)): continue
        unexpl.append((d["day"],pg,kind,s))
print("unexplained:",len(unexpl))
for u in unexpl: print(u)
