import json, re, collections
days=json.load(open("days_raw.json"))
def mins(t): return int(t[:2])*60+int(t[3:])
issues=[]
tot=collections.defaultdict(lambda:[0,0,0])
print("days:",len(days),[d["day"] for d in days]==list(range(1,69)))
print("types:",collections.Counter(d["type"] for d in days))
print("rest:",[d["day"] for d in days if d["type"]=="rest"])
print("practical:",[d["day"] for d in days if d["type"]=="practical"])
for d in days:
    if d["type"]=="rest": continue
    a=s=c=0
    flat=[]
    for sec in d["sections"]:
        for p in sec["periods"]:
            flat.append((sec,p))
            for it in p["items"]:
                if it["type"]=="video":
                    a+=it["attendance"]["minutes"]; s+=it["study"]["minutes"]
                    tot[sec["subject"]][0]+=it["attendance"]["minutes"]; tot[sec["subject"]][1]+=it["study"]["minutes"]
                else:
                    c+=it["study"]["minutes"]; tot[sec["subject"]][2]+=it["study"]["minutes"]
            if p["start"]!=p["itemsStart"] or p["end"]!=p["itemsEnd"]:
                issues.append((d["day"],"period range mismatch",p["index"],p["start"],p["end"],p["itemsStart"],p["itemsEnd"]))
            for it in p["items"]:
                for k in ("attendance","study"):
                    if k in it and it[k]["minutes"]<=0: issues.append((d["day"],"nonpositive duration",it["title"]))
    total=a+s+c
    d["computed"]={"attendance":a,"study":s,"courses":c,"total":total}
    if total!=d["statedStudyMinutes"]:
        issues.append((d["day"],"study total",total,d["statedStudyMinutes"],"diff",total-d["statedStudyMinutes"]))
    if flat[0][1]["start"]!=d["statedStart"] or flat[-1][1]["end"]!=d["statedEnd"]:
        issues.append((d["day"],"day range",flat[0][1]["start"],flat[-1][1]["end"],d["statedStart"],d["statedEnd"]))
    # period numbering contiguous
    idx=[p["index"] for _,p in flat]
    if idx!=list(range(1,len(idx)+1)): issues.append((d["day"],"period idx",idx))
    # section range text
    for sec in d["sections"]:
        ps=sec["periods"]
        m=re.match(r"^(?:من )?الفترة (\d+)(?: للفترة (\d+))? · من (\d{1,2}):(\d{2}) (ص|م) لـ (\d{1,2}):(\d{2}) (ص|م)$",sec["rangeText"] or "")
        if not m: issues.append((d["day"],"range text",sec["rangeText"])); continue
        a0,a1=int(m.group(1)),int(m.group(2) or m.group(1))
        if (ps[0]["index"],ps[-1]["index"])!=(a0,a1): issues.append((d["day"],"section periods",sec["subject"],a0,a1,ps[0]["index"],ps[-1]["index"]))
        def ab(h,mi,ap): return (int(h)%12)*60+int(mi)+(720 if ap=="م" else 0)
        if ab(*m.group(3,4,5))!=mins(ps[0]["start"]) or ab(*m.group(6,7,8))!=mins(ps[-1]["end"]):
            issues.append((d["day"],"section time",sec["subject"],sec["rangeText"],ps[0]["start"],ps[-1]["end"]))
    # interludes continuity: break start == previous period end ; next period start == break end
    for il in d["interludes"]:
        ap=il["afterPeriod"]
        pe=[p for _,p in flat if p["index"]==ap]
        pn=[p for _,p in flat if p["index"]==(ap or 0)+1]
        if pe and il["start"]!=pe[0]["end"]: issues.append((d["day"],"interlude start",il["type"],il["start"],pe[0]["end"]))
        if pn and il["end"]!=pn[0]["start"]: issues.append((d["day"],"interlude end",il["type"],il["end"],pn[0]["start"],ap))
print("issues:",len(issues))
for i in issues[:80]: print(i)
print()
def hm(m): return f"{m//60}h{m%60:02d}"
g=[0,0,0]
for k,v in tot.items():
    print(k,hm(v[0]),hm(v[1]),hm(v[2]),"=",hm(sum(v)))
    for i in range(3): g[i]+=v[i]
print("ALL",hm(g[0]),hm(g[1]),hm(g[2]),"=",hm(sum(g)))
