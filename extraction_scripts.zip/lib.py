import unicodedata, pdfplumber, re

MIRROR={"(":")",")":"(","[":"]","]":"[","{":"}","}":"{","<":">",">":"<","«":"»","»":"«"}

def strong(ch):
    # classify char for simplified bidi on NFKC-normalised text
    b = unicodedata.bidirectional(ch)
    if b in ("R","AL"): return "R"
    if b in ("L","EN","AN"): return "L"
    return "N"

def visual_to_logical(vis):
    """vis: string in visual left-to-right order (already NFKC-normalised per char, may contain multi-char).
    Returns logical string assuming RTL base direction."""
    if not vis: return ""
    cls=[strong(c) for c in vis]
    # resolve neutrals: between same-direction runs take that direction, else base R
    n=len(vis); res=cls[:]
    i=0
    while i<n:
        if res[i]=="N":
            j=i
            while j<n and cls[j]=="N": j+=1
            left=cls[i-1] if i>0 else "R"
            right=cls[j] if j<n else "R"
            d = left if left==right else "R"
            # numbers: ':' '.' '/' ',' '-' between digits stay in LTR run
            for k in range(i,j): res[k]=d
            i=j
        else: i+=1
    # runs
    runs=[]; 
    for c,d in zip(vis,res):
        if runs and runs[-1][0]==d: runs[-1][1].append(c)
        else: runs.append([d,[c]])
    out=[]
    for d,chs in reversed(runs):
        out.append("".join(MIRROR.get(x,x) for x in reversed(chs)) if d=="R" else "".join(chs))
    return "".join(out)

def norm_chars(chars):
    """chars sorted visually by x0; returns visual string with NFKC applied per char (presentation forms resolved)."""
    s=[]
    for c in chars:
        t=unicodedata.normalize("NFKC",c["text"])
        if len(t)>1 and all(strong(x)=="R" for x in t):
            t=t[::-1]   # ligature glyph: keep logical order after the later full reversal
        s.append(t)
    return "".join(s)

def _is_mark(c):
    t=unicodedata.normalize("NFKC",c["text"])
    return bool(t) and all(unicodedata.category(x)=="Mn" for x in t)

def _place_marks(chars):
    """Combining marks must follow their base in LOGICAL order, i.e. precede it in visual (L->R) order."""
    bases=[c for c in chars if not _is_mark(c)]
    marks=[c for c in chars if _is_mark(c)]
    if not marks: return chars
    seq=list(bases)
    for m in marks:
        cx=(m["x0"]+m["x1"])/2
        cand=[b for b in bases if b["x0"]-0.8<=cx<=b["x1"]+0.8] or bases
        b=min(cand,key=lambda b:abs((b["x0"]+b["x1"])/2-cx))
        seq.insert(seq.index(b),m)
    return seq

def cell_text(chars):
    chars=_place_marks(sorted(chars,key=lambda c:c["x0"]))
    vis=norm_chars(chars)
    if not any(strong(c)=="R" for c in vis):
        return re.sub(r"\s+"," ",vis).strip()   # pure LTR cell: visual order == logical order
    # mirrored brackets are not an issue for our content; collapse spaces
    lg=visual_to_logical(vis)
    return re.sub(r"\s+"," ",lg).strip()

def _attach_marks(chars):
    out=[]
    base=[c for c in chars if unicodedata.category(unicodedata.normalize("NFKC",c["text"])[:1] or "x")!="Mn"]
    for c in chars:
        t=unicodedata.normalize("NFKC",c["text"])
        if t and all(unicodedata.category(x)=="Mn" for x in t):
            cx=(c["x0"]+c["x1"])/2
            cand=[b for b in base if b["x0"]-1<=cx<=b["x1"]+1 and abs(b["top"]-c["top"])<10]
            if cand:
                b=min(cand,key=lambda b:abs(b["top"]-c["top"]))
                c=dict(c); c["top"]=b["top"]
        out.append(c)
    return out

def lines_of(page, tol=2.2):
    ch=[c for c in page.chars if c["text"].strip()!="" or True]
    ch=sorted(ch,key=lambda c:(round(c["top"],0),c["x0"]))
    rows=[]
    for c in sorted(_attach_marks(page.chars),key=lambda c:c["top"]):
        for r in rows:
            if abs(r["top"]-c["top"])<=tol:
                r["chars"].append(c); break
        else:
            rows.append({"top":c["top"],"chars":[c]})
    rows.sort(key=lambda r:r["top"])
    return rows

def split_cells(chars, gap=9.0):
    chars=sorted(chars,key=lambda c:c["x0"])
    cells=[]; cur=[chars[0]]
    for a,b in zip(chars,chars[1:]):
        if b["x0"]-a["x1"]>gap: cells.append(cur); cur=[b]
        else: cur.append(b)
    cells.append(cur)
    return cells
